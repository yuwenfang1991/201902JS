<template>
    <div>
        <button @click="show">点我啊</button>
    </div>
</template>
<script>
// 引入 Message组件 引入的是 Message/index.js
import {Message} from './Message';
import Vue from 'vue';
// 使用插件 
Vue.use(Message); 

// 注册组件用的 或者给vue的原型上添加方法
// Vue.component()  Vue.prototype.xxx
// 使用Vue.use 内部会自动调用install 方法
export default {
    methods:{
        show(){
            this.$message({
               message:'hello',
               type:'success',
               duration:3000 
            })
        }
    }
}
</script>