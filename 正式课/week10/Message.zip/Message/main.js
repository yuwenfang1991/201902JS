import Vue from 'vue';
// 默认内部是基于vue-cli3.0


// npm i element-ui 安装element-ui
// import ElementUI from 'element-ui'; // 引入组件库
// import 'element-ui/lib/theme-chalk/index.css'; // 引入样式
// Vue.use(ElementUI); // 注册这个组件库

import App from './App.vue';
export default new Vue({
    el:'#app',
    // 调用render函数 可以将某个组件渲染到#app上
    // createElement
    render:h=>h(App)
        // h是一个函数 第一个参数是标签
        //<h1 id="aa">hello world</h1>
        /*h('h1',{ // jsx
            attrs:{id:'aaa'},
            on:{
                click(){
                    alert(1)
                }
            }
        },'我很帅')*/
});
// sudo npm install @vue/cli  @vue/cli-service-global -g
// 启动项目需要在当前目录下执行 vue serve命令
// 会自动查找main.js  如果找不到 会继续找 App.vue

// main.js -> App
// App -> 使用了消息组件 Message/index.js
// index 中倒出了一个方法
// index -> Message.vue
// Message.vue （add / remove dom元素）