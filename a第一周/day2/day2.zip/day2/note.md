# day1

## Number类型

> 正数 负数 小数 0 NaN(非数字)

### 数字类型转换

#### Number() 严格转换

> 主要针对字符串，只要字符串中包含非有效数字字符，就返回NaN

Number('') // 0
Number('10px') // NaN

Number(true) // 1
Number(false) // 0

#### parseInt() 提取数字 进行取整
> 从左到右依次进行提取，将字符串中数字内容 提取出来，中途遇到非有效字符停止提取
parseInt('10px') // 10

parseInt('10.5px') // 10
parseInt(10.5) // 10

#### parseFloat() 
> 比parseInt 多识别一个小数点 支持小数提取
parseInt('10.5px') // 10
parseFloat('10.5px') // 10.5

### isNaN() 检测一个值是不是NaN

isNaN(val) 如果返回true 说明是非有效数字（NaN）
isNaN(val) 如果返回false 说明是有效数字

isNaN('10') // false

isNaN() 先将值用Number()转换成数字类型，然后在判断是不是NaN

## Boolean

- true(真)

- false(假)

### 其他类型转换为boolean

> 记住这句话：0 '' NaN null undefined 这五个值转换为boolean都是false 其余都是true

#### 转换方法
Boolean()
!!

- !取反
 先将值转换成boolean 再进行取反
 !0 => true
