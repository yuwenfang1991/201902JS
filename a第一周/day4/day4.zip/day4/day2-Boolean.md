# JS中数据类型之Boolean

## 1.Boolean类型的转换
> 0 '' null undefined NaN 转换为Boolean类型都是false 其余都是true

## 2.Boolean类型转换的方法

### Boolean()

```
Boolean(0) // false
Boolean('') // false
Boolean(null) // false
Boolean(undefined) // false
Boolean(NaN) // false

// 其余的
Boolean(1) // true
Boolean('abc') // true
Boolean([]) // true
```

### !!操作符
> !!等价于Boolean() 将其他类型转换为Boolean类型

```
!!0 // false
!!NaN // false

!!1 // true
```

## 3.!取反
> !值 先将值转换为Boolean值（true或false）再进行取反 true => false

```
!!0 // false
!0 // true

!true // false

!1 // false
```
