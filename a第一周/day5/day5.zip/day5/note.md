# day5

## 函数

- 函数的定义、执行

- 函数传参（形参 实参 arguments）

- 函数的返回值 return