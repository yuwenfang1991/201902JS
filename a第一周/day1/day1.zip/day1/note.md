# day1

## JavaScript 三大部分

- ECMAScript(标准)简称ES 规定了JS中核心内容（语法 变量 数据类型 语句 关键字 运算符等）

- DOM(文档对象模型) 提供了一些属性和方法 让我们能够操作页面中的html元素（document.getElementById()）

- BOM(浏览器对象模型) 提供了一些属性和方法 让我们能够操作浏览器(window.open())

## JS引入方式

- 外链式

- 内嵌式

- 行内式

## JS中的变量
变量/常量：存储值和代表值
var 变量名 = 值
const 常量名 = 值

## JS中的输出方式

### 页面中输出

- 1.document.write() 将内容直接输出到body中

- 2.innerHTML 将指定内容输出到某个页面元素当中 能够识别内容中的html标签

- 3.innerText 将指定内容输出到某个页面元素当中 把所有内容都当做 普通文本输出到元素中

## 下午

### 输出方式

- 弹窗输出

```
alert() 提示框
confirm() 确认框
prompt() 输入框
```

- 控制台输出 （JS调试）
console.log()
console.dir()

### 命名规范

### JS中的数据类型

#### 1.基本数据类型（原始数据类型）

- Number 数字类型

- String 字符串类型

- Boolean 布尔类型

- Null  空指针对象

- Undefined 未定义

#### 2.引用数据类型（复合数据类型）

- 对象数据类型
  - 普通对象 object {}
  - 数组 array []
  - 正则 regexp /\d+/
  - Date 日期对象
  - Math 数学工具对象
  ...

- 函数数据类型
 - function  function fe() {}

 ### 数据类型的检测
- typeof

- instanceof

- constrcutor

- Object.prototype.toString.call()







