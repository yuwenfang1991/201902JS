// 出来一个弹窗 弹窗的内容 'hello word!'
alert('hello word!')